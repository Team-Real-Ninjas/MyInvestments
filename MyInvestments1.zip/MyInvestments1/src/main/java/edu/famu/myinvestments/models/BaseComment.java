package edu.famu.myinvestments.models;

import com.google.cloud.firestore.annotation.DocumentId;

public abstract class BaseComment {

    @DocumentId
    protected String id;
    protected String content;
    protected long like;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getLike() {
        return like;
    }

    public void setLike(long like) {
        this.like = like;
    }


}