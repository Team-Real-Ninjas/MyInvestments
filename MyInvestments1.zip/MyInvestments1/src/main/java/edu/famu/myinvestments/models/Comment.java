package edu.famu.myinvestments.models;

import com.google.firebase.remoteconfig.User;

public class Comment extends BaseComment {
    private User author;
    private Post post;

    public Comment(){

    }

    public Comment(String id, String content, long like, User author, Post post) {
        this.id = id;
        this.content = content;
        this.like = like;
        this.author = author;
        this.post = post;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }
}
