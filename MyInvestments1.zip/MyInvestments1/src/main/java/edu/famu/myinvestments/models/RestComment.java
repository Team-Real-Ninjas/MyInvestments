package edu.famu.myinvestments.models;

import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;

public class RestComment extends BaseComment {
    private DocumentReference author;
    private DocumentReference post;

    public RestComment(){

    }

    public RestComment(String id, String content, long like, DocumentReference author, DocumentReference post) {
        this.id = id;
        this.content = content;
        this.like = like;
        this.author = author;
        this.post = post;
    }

    public DocumentReference getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        Firestore db = FirestoreClient.getFirestore();
        this.author = db.collection("User").document(author);
    }

    public DocumentReference getPost() {
        return post;
    }

    public void setPost(String post) {
        Firestore db = FirestoreClient.getFirestore();
        this.post = db.collection("Post").document(post);
    }
}
