package edu.famu.myinvestments.models;

import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;

import java.util.ArrayList;

public class RestPost extends BasePost {
    private DocumentReference author;

    public RestPost(){

    }

    public RestPost(String id, String title, String content, ArrayList<String> tags, boolean showComments, long likes, DocumentReference author) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.tags = tags;
        this.showComments = showComments;
        this.likes = likes;
        this.author = author;
    }

    public RestPost(String id, String title, String content, ArrayList<String> tags, boolean showComments, long likes, String author) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.tags = tags;
        this.showComments = showComments;
        this.likes = likes;
        this.setAuthor(author);
    }

    public DocumentReference getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        Firestore db = FirestoreClient.getFirestore();
        this.author = db.collection("User").document(author);
    }

}
