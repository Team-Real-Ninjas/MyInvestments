package edu.famu.myinvestments.models;

import com.google.firebase.remoteconfig.User;

import java.util.ArrayList;

public class Post extends BasePost {
    private User author;

    public Post(){

    }

    public Post(String id, String title, String content, ArrayList<String> tags, boolean showComments, long likes, User user) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.tags = tags;
        this.showComments = showComments;
        this.likes = likes;
        this.author = user;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User user) {
        this.author = user;
    }

}
